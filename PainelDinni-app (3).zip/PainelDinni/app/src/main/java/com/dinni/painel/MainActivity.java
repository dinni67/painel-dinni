package com.dinni.painel;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private void startFps() {
        Intent s = new Intent(this, FpsService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
    }

    private boolean canOverlay() {
        if (Settings.canDrawOverlays(this)) return true;
        toast("Permita 'Sobrepor a outros apps' e toque de novo");
        go(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
        return false;
    }

    private void go(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }

    class Bridge {
        @JavascriptInterface
        public void openApp(String pkg) {
            runOnUiThread(() -> {
                Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
                if (i == null) { toast("App não instalado"); return; }
                go(i);
            });
        }

        @JavascriptInterface
        public void openSettings(String action) {
            runOnUiThread(() -> {
                try { go(new Intent(action)); }
                catch (Exception e) {
                    try { go(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception x) { toast("Não foi possível abrir"); }
                }
            });
        }

        @JavascriptInterface
        public void openFreeFire() {
            runOnUiThread(() -> {
                String[] pk = {"com.dts.freefireth", "com.dts.freefiremax"};
                for (String p : pk) {
                    Intent i = getPackageManager().getLaunchIntentForPackage(p);
                    if (i != null) { go(i); return; }
                }
                toast("Free Fire não instalado");
            });
        }

        @JavascriptInterface
        public void startOverlay() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
                if (canOverlay()) startFps();
            });
        }

        @JavascriptInterface
        public void stopOverlay() {
            runOnUiThread(() -> stopService(new Intent(MainActivity.this, FpsService.class)));
        }

        @JavascriptInterface
        public boolean isOverlayOn() { return FpsService.running; }

        @JavascriptInterface
        public void ligarEJogar() {
            runOnUiThread(() -> {
                if (!canOverlay()) return;
                startFps();
                String[] pk = {"com.dts.freefireth", "com.dts.freefiremax"};
                for (String p : pk) {
                    Intent i = getPackageManager().getLaunchIntentForPackage(p);
                    if (i != null) { go(i); return; }
                }
                toast("Free Fire não instalado");
            });
        }

        @JavascriptInterface
        public void openMyAppSettings() {
            runOnUiThread(() -> go(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        }

        @JavascriptInterface
        public void openBatteryExempt() {
            runOnUiThread(() -> {
                try { go(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName()))); }
                catch (Exception e) {
                    try { go(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception x) { toast("Não foi possível abrir"); }
                }
            });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            runOnUiThread(() -> {
                try { go(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception e) { toast("Não foi possível abrir"); }
            });
        }

        @JavascriptInterface
        public void openAppDetails() {
            runOnUiThread(() -> {
                String[] pk = {"com.dts.freefireth", "com.dts.freefiremax"};
                for (String p : pk) {
                    if (getPackageManager().getLaunchIntentForPackage(p) != null) {
                        go(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + p)));
                        return;
                    }
                }
                toast("Free Fire não instalado");
            });
        }
    }
}
