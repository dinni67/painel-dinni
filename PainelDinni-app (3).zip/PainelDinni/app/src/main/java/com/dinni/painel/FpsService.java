package com.dinni.painel;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.TextView;

public class FpsService extends Service implements Choreographer.FrameCallback {
    static volatile boolean running = false;
    private WindowManager wm;
    private TextView tv;
    private WindowManager.LayoutParams lp;
    private long lastNs = 0;
    private int frames = 0;
    private float hz = 60f;

    @Override public IBinder onBind(Intent i) { return null; }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override
    public void onCreate() {
        super.onCreate();
        startFg();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        tv = new TextView(this);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(14);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setPadding(dp(12), dp(6), dp(12), dp(6));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xCC000000);
        g.setCornerRadius(dp(14));
        g.setStroke(dp(1), 0xFFFF2A2A);
        tv.setBackground(g);
        tv.setText("-- FPS");
        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = dp(12);
        lp.y = dp(60);
        tv.setOnTouchListener(new android.view.View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(android.view.View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + (int) (e.getRawX() - tx);
                        lp.y = sy + (int) (e.getRawY() - ty);
                        try { wm.updateViewLayout(tv, lp); } catch (Exception x) {}
                        return true;
                }
                return false;
            }
        });
        try { hz = wm.getDefaultDisplay().getRefreshRate(); } catch (Exception e) {}
        wm.addView(tv, lp);
        running = true;
        Choreographer.getInstance().postFrameCallback(this);
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("fps", "Contador de FPS", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "fps") : new Notification.Builder(this);
        Notification n = b.setContentTitle("Painel do Dinni")
                .setContentText("Contador de FPS ativo")
                .setSmallIcon(android.R.drawable.ic_dialog_info).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1, n);
    }

    @Override
    public int onStartCommand(Intent i, int f, int id) { return START_STICKY; }

    @Override
    public void doFrame(long ns) {
        if (!running) return;
        if (lastNs == 0) lastNs = ns;
        frames++;
        long dt = ns - lastNs;
        if (dt >= 1000000000L) {
            int f = Math.round(frames * 1e9f / dt);
            frames = 0;
            lastNs = ns;
            tv.setText(f + " FPS · " + Math.round(hz) + "Hz");
            tv.setTextColor(f >= hz * 0.9f ? 0xFF4CFF7A : f >= hz * 0.6f ? 0xFFFFD54A : 0xFFFF4A4A);
        }
        Choreographer.getInstance().postFrameCallback(this);
    }

    @Override
    public void onDestroy() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
        try { wm.removeView(tv); } catch (Exception e) {}
        super.onDestroy();
    }
}
